#!/bin/bash

cd /var/lib/testnative/
node testnative
